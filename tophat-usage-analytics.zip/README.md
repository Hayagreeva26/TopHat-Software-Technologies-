# TopHat — Usage Analytics Starter

Examples and scripts for session funnels, anomaly detection, and ingestion from MongoDB/Postgres.
