from pymongo import MongoClient
import pandas as pd
import os
from dotenv import load_dotenv
load_dotenv()

def load_sessions(limit=1000):
    client = MongoClient(os.getenv("MONGO_URI"))
    db = client.get_database()
    coll = db.sessions
    docs = coll.find().limit(limit)
    df = pd.DataFrame(list(docs))
    return df
