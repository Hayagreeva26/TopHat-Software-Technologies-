import pandas as pd
import numpy as np
from statsmodels.tsa.seasonal import STL

def detect_anomaly(ts_series, threshold=3.5):
    stl = STL(ts_series, period=7, robust=True)
    res = stl.fit()
    resid = res.resid
    z = (resid - resid.mean()) / resid.std()
    anomalies = z[abs(z) > threshold]
    return anomalies

if __name__ == "__main__":
    idx = pd.date_range("2025-01-01", periods=60)
    s = pd.Series(np.random.poisson(100, size=60), index=idx)
    anomalies = detect_anomaly(s)
    print("Anomalies:", anomalies)
