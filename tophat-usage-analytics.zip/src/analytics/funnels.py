import pandas as pd

def compute_funnel(df, steps):
    df = df.sort_values(['user_id', 'ts'])
    funnel_counts = {}
    for step in steps:
        mask = df['event'] == step
        funnel_counts[step] = df[mask]['user_id'].nunique()
    return funnel_counts
