import pandas as pd
from src.analytics.anomaly_detector import detect_anomaly

def test_detect_anomaly_no_anoms():
    idx = pd.date_range("2025-01-01", periods=21)
    s = pd.Series([10]*21, index=idx)
    anoms = detect_anomaly(s)
    assert len(anoms) == 0
